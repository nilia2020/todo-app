import React from 'react';
import './TodoSearch.css';

function TodoSearch() {
  return (
    <input className="TodoSearch" placeholder="Cebolla" />
  );
}

export { TodoSearch };
